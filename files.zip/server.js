// Ghar to Health - backend (no npm packages needed, Node 18+)
// Run:  node server.js   ->  http://localhost:3000
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const ADMIN_KEY = process.env.ADMIN_KEY || 'change-this-key'; // used to view bookings
const PUBLIC_DIR = path.join(__dirname, 'public');
const DATA_FILE = path.join(__dirname, 'data', 'bookings.json');

const SERVICES = {
  home: ['Plumber', 'Electrician', 'Carpenter', 'AC Service', 'Cleaning', 'Sofa Cleaning', 'Pest Control', 'Appliance Repair'],
  medical: ['Doctor Consultation', 'Medicine Delivery', 'Lab Tests', 'Health Check-up']
};

const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript',
  '.json': 'application/json', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.webp': 'image/webp'
};

function readBookings() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch { return []; }
}
function saveBookings(list) {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  fs.writeFileSync(DATA_FILE, JSON.stringify(list, null, 2));
}

function send(res, status, body, headers = {}) {
  const isObj = typeof body === 'object' && !Buffer.isBuffer(body);
  res.writeHead(status, { 'Content-Type': isObj ? 'application/json' : 'text/plain', ...headers });
  res.end(isObj ? JSON.stringify(body) : body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', c => {
      data += c;
      if (data.length > 10000) { reject(new Error('too large')); req.destroy(); }
    });
    req.on('end', () => { try { resolve(JSON.parse(data || '{}')); } catch { reject(new Error('bad json')); } });
    req.on('error', reject);
  });
}

const clean = (v, max = 200) => String(v || '').replace(/[<>]/g, '').trim().slice(0, max);

function validateBooking(b) {
  const type = b.type === 'medical' ? 'medical' : 'home';
  const booking = {
    type,
    service: clean(b.service, 60),
    name: clean(b.name, 80),
    phone: clean(b.phone, 15).replace(/[\s-]/g, ''),
    address: clean(b.address, 250),
    date: clean(b.date, 20),
    notes: clean(b.notes, 300)
  };
  if (!SERVICES[type].includes(booking.service)) return { error: 'Please choose a valid service.' };
  if (booking.name.length < 2) return { error: 'Please enter your name.' };
  if (!/^(\+91)?[6-9]\d{9}$/.test(booking.phone)) return { error: 'Enter a valid 10-digit mobile number.' };
  if (booking.address.length < 5) return { error: 'Please enter your address.' };
  return { booking };
}

async function handleApi(req, res, url) {
  if (req.method === 'GET' && url.pathname === '/api/services') return send(res, 200, SERVICES);

  if (req.method === 'POST' && url.pathname === '/api/bookings') {
    let body;
    try { body = await readBody(req); } catch (e) { return send(res, 400, { error: 'Invalid request.' }); }
    const { booking, error } = validateBooking(body);
    if (error) return send(res, 400, { error });
    const list = readBookings();
    const saved = { id: 'GTH' + Date.now().toString(36).toUpperCase(), status: 'new', createdAt: new Date().toISOString(), ...booking };
    list.push(saved);
    saveBookings(list);
    return send(res, 201, { message: 'Booking received! We will call you shortly.', id: saved.id });
  }

  if (req.method === 'GET' && url.pathname === '/api/bookings') {
    if (req.headers['x-admin-key'] !== ADMIN_KEY) return send(res, 401, { error: 'Unauthorized' });
    return send(res, 200, readBookings());
  }

  return send(res, 404, { error: 'Not found' });
}

function serveStatic(req, res, url) {
  let file = decodeURIComponent(url.pathname);
  if (file === '/') file = '/index.html';
  const full = path.normalize(path.join(PUBLIC_DIR, file));
  if (!full.startsWith(PUBLIC_DIR)) return send(res, 403, 'Forbidden');
  fs.readFile(full, (err, data) => {
    if (err) return send(res, 404, 'Not found');
    send(res, 200, data, { 'Content-Type': MIME[path.extname(full).toLowerCase()] || 'application/octet-stream' });
  });
}

http.createServer((req, res) => {
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname.startsWith('/api/')) return handleApi(req, res, url).catch(() => send(res, 500, { error: 'Server error' }));
  if (req.method !== 'GET') return send(res, 405, 'Method not allowed');
  serveStatic(req, res, url);
}).listen(PORT, () => console.log(`Ghar to Health running at http://localhost:${PORT}`));
